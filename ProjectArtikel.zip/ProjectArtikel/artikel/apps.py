from django.apps import AppConfig


class ArtikelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'artikel'
